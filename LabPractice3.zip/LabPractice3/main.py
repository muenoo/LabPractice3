import model.Dataset as Dataset
import model.LM as LM

import torch

torch.manual_seed(0)

net = LM.Net()
trainer = LM.Trainer(max_epochs = 10)


trainer.fit(net)   
trainer.test()
trainer.callback_metrics 